package com.spring.db.jdbc.score.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.spring.db.jdbc.score.commons.ScoreMapper;
import com.spring.db.jdbc.score.model.ScoreVO;

@Repository
public class ScoreDAO implements IScoreDAO {
	//내부 클래스
	//두 클래스가 긴밀한 관계가 있을때 선언이 가능
	//해당 클래스안에서만 사용할 클래스를 굳이 새 파일을 만들지 않고도 선언이 가능
	class ScoreMapper implements RowMapper<ScoreVO>{
		@Override
		public ScoreVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			ScoreVO score = new ScoreVO();
			
			score.setStu_id(rs.getInt("stu_id"));
			score.setStu_name(rs.getString("stu_name"));
			score.setKor(rs.getInt("kor"));
			score.setEng(rs.getInt("eng"));
			score.setMath(rs.getInt("math"));
			score.setTotal(rs.getInt("total"));
			score.setAverage(rs.getDouble("average"));
			
			return score;
		}
	}
	
	//전통방식의 jdbc
//	private String driverName = "oracle.jdbc.driver.OracleDriver";
//	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
//	private String uid = "spring";
//	private String upw = "spring";
	
//	@Override
//	public void insertScore(ScoreVO scores) {
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		
//		String sql = "insert into scores values(id_seq.nextval,?,?,?,?,?,?)";
//		try {
//			Class.forName(driverName);
//			conn = DriverManager.getConnection(url, uid, upw);
//			pstmt = conn.prepareStatement(sql);
//			
//			pstmt.setString(1, scores.getStu_name());
//			pstmt.setInt(2, scores.getKor());
//			pstmt.setInt(3, scores.getEng());
//			pstmt.setInt(4, scores.getMath());
//			pstmt.setInt(5, scores.getTotal());
//			pstmt.setDouble(6, scores.getAveraeg());
//			
//			pstmt.executeUpdate();
//			System.out.println("점수등록 성공");	
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			
//		} finally {
//			try {
//				conn.close();
//				pstmt.close();
//			} catch (SQLException e) {}
//		}
//	}
	
	//spring jdbc방식의 처리 : JdbcTemplate
	@Autowired
	private JdbcTemplate template;
	
	@Override
	public void insertScore(ScoreVO scores) {
		String sql = "insert into scores values(id_seq.nextval,?,?,?,?,?,?)";
		
		template.update(sql, scores.getStu_name(), 
				scores.getKor(), scores.getEng(), scores.getMath(), 
				scores.getTotal(), scores.getAverage());	
	}

	//전통방식의 jdbc
//	@Override
//	public List<ScoreVO> selectAllScores() {
//		List<ScoreVO> list = new ArrayList<ScoreVO>();
//		
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		
//		String sql = "select * from scores";
//		try {
//			Class.forName(driverName);
//			conn = DriverManager.getConnection(url, uid, upw);
//			pstmt = conn.prepareStatement(sql);
//			rs = pstmt.executeQuery();
//			
//			while(rs.next()){
//				ScoreVO vo = new ScoreVO();
//				vo.setStu_id(rs.getInt("stu_id"));
//				vo.setStu_name(rs.getString("stu_name"));
//				vo.setKor(rs.getInt("kor"));
//				vo.setEng(rs.getInt("eng"));
//				vo.setMath(rs.getInt("math"));
//				vo.setTotal(rs.getInt("total"));
//				vo.setAveraeg(rs.getDouble("average"));
//				
//				list.add(vo);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				conn.close();
//				rs.close();
//				pstmt.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		return list;
//	}
	
	//spring jdbc 방식
	//template이 connection, prepareStatement, sql문 실행하여 resultSet까지 자동으로 받아온다
	//template이 select한 행 개수만큼 ScoreMapper의 mapRow를 실행하여 resultSet과 행번호를 넘긴다
	//mapRow에서는 객체를 포장하여 반환하고 template은 이를 리스트 추가하고 리스트를 반환한다
//	@Override
//	public List<ScoreVO> selectAllScores() {
//		String sql = "select * from scores";
//      //query : select 결과가 여러 행일떄, 리턴 타입은 list
//		//ScoreMapper 클래스 안만들고 익명클래스로 대체가능
//		return template.query(sql, new ScoreMapper());
//	}
	
	//익명클래스이용
	@Override
	public List<ScoreVO> selectAllScores() {
		String sql = "select * from scores order by stu_id asc";
		return template.query(sql, (rs, rownum) -> {
			ScoreVO score = new ScoreVO();
			
			score.setStu_id(rs.getInt("stu_id"));
			score.setStu_name(rs.getString("stu_name"));
			score.setKor(rs.getInt("kor"));
			score.setEng(rs.getInt("eng"));
			score.setMath(rs.getInt("math"));
			score.setTotal(rs.getInt("total"));
			score.setAverage(rs.getDouble("average"));
			
			return score;
		});
	}

	@Override
	public void deleteScores(int stu_id) {
		String sql = "delete from scores where stu_id = ?";
		template.update(sql, stu_id);	
	}

	@Override
	public ScoreVO selectOne(int stu_id) {
		String sql = "select * from scores where stu_id = ?";
		//queryForObject() : select 결과가 한 행일때, 리턴타입은 객체(vo)
		return template.queryForObject(sql, new ScoreMapper(), stu_id);
	}
}
