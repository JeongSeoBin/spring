package com.spring.db.jdbc.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.db.jdbc.board.model.BoardVO;
import com.spring.db.jdbc.board.repository.IBoardDAO;

@Service
public class BoardService implements IBoardService {
	@Autowired
	private IBoardDAO dao;

	@Override
	public void insertArticle(BoardVO vo) {
		dao.insertArticle(vo);
	}

	@Override
	public List<BoardVO> getArticles() {
		return dao.getArticles();
	}

	@Override
	public BoardVO getArticle(int board_num) {
		return dao.getArticle(board_num);
	}

	@Override
	public void deleteArticle(int board_num) {
		dao.deleteArticle(board_num);
	}

	@Override
	public void updateArticle(BoardVO vo, int board_num) {
		dao.updateArticle(vo, board_num);
	}
}
