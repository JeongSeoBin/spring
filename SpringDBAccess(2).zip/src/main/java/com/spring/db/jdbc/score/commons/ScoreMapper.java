package com.spring.db.jdbc.score.commons;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.spring.db.jdbc.score.model.ScoreVO;

//jdbcTemplate에서 select를 위한 resultset사용을 편하게 하기 위한 클래스
//rowMapper 인터페이스를 구현
public class ScoreMapper implements RowMapper<ScoreVO>{

	//mapRow: 객체를 포장해 리턴한다 
	@Override
	public ScoreVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		ScoreVO score = new ScoreVO();
		
		score.setStu_id(rs.getInt("stu_id"));
		score.setStu_name(rs.getString("stu_name"));
		score.setKor(rs.getInt("kor"));
		score.setEng(rs.getInt("eng"));
		score.setMath(rs.getInt("math"));
		score.setTotal(rs.getInt("total"));
		score.setAverage(rs.getDouble("average"));
		
		return score;
	}
}
